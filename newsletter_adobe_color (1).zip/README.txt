# Bài tập phối màu Newsletter với Adobe Color

## File trong bài
- `newsletter_version1.html`: Phiên bản 1 - bộ màu tươi sáng.
- `newsletter_version2.html`: Phiên bản 2 - bộ màu chuyên nghiệp/đậm hơn.
- `index.html`: Mở nhanh phiên bản 1.
- `README.txt`: Hướng dẫn.

## Bộ màu
### Phiên bản 1
- Primary: #4CAF50
- Secondary: #FFC107
- Accent: #2196F3
- Text: #333333
- Light background: #F8F9FA

### Phiên bản 2
- Primary: #3F2B96
- Secondary: #A8C0FF
- Accent: #FF6B6B
- Text: #242424
- Light background: #F3F1FA

## Cách chạy
Mở `index.html` hoặc một trong hai file phiên bản bằng Chrome.
Bootstrap được tải từ CDN nên máy cần có Internet.

## Nộp bài
Có thể đưa 3 file HTML lên GitHub hoặc CodePen, sau đó nộp link repository/CodePen theo yêu cầu bài.
